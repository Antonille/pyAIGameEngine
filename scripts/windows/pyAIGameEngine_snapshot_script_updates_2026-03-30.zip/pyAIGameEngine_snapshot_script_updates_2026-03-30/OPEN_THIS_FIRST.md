Replace the matching files under:
- C:\PythonDev\Dev1\pyGames\pyAIGameEngine\scripts\windows
- C:\PythonDev\Dev1\pyGames\pyAIGameEngine\scripts\bash

This patch standardizes future snapshots on a rooted ZIP layout:
- pyAIGameEngine/

It also keeps backward-compatible detection for older rootless sparse snapshots.
